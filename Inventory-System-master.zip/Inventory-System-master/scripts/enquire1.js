function goback() 
{
	
        	window.location = "staff.html";    
}

function submit() {
    alert("Following are the all coffee details");
}


