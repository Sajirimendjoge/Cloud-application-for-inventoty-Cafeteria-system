function goback() 
{
	
        	window.location = "admin.html";

    
}

function submit() {

	dbproject.py() 
    alert("Following are the all coffee details");
}

