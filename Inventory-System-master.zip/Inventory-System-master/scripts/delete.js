function goBack() {
   
        window.location = "admin.html";
   
}

function submit() {
    alert("Coffee deleted successfully");
}


