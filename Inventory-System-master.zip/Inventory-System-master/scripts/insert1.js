function goback()
 {
   
        window.location = "staff.html";  
}




function submit() {
    alert("Coffee added successfully");
}



