
function insert() {
    window.location = "insert1.html";
}

function del() {
    window.location = "delete1.html";
}

function enquire() {
    window.location = "enquire1.html";
}

function update() {
    window.location = "update1.html";
}


function logout() {
    window.location = "index.html";
}
