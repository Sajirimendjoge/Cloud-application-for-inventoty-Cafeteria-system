function goBack()

{
    window.location = "staff.html";  
}

function submit() 
{
    alert("Coffee updated successfully");
}
