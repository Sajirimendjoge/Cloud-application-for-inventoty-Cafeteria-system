function goback()
 {
   
        window.location = "admin.html";  
}




function submit() {
    alert("Coffee added successfully");
}



