function insert() 
{
    window.location = "insert.html";
}

function del() {
    window.location = "delete.html";
}

function enquire() {
    window.location = "enquire.html";
}

function update() 
{
    window.location = "update.html";
}

function logout() 
{
    window.location = "index.html";
}