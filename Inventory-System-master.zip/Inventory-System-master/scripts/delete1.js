function goBack() {
   
        window.location = "staff.html";
   
}

function submit() {
    alert("Coffee deleted successfully");
}


